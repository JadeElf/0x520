package org.thoughtcrime.securesms.components.webrtc;

public enum WebRtcLocalRenderState {
  GONE,
  SMALL,
  LARGE
}
