package org.thoughtcrime.securesms.conversation.ui.error;

public enum TrustAndVerifyResult {
  TRUST_AND_VERIFY,
  TRUST_VERIFY_AND_RESEND,
  UNKNOWN
}
