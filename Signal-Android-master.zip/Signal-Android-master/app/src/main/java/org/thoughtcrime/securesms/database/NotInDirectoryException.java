package org.thoughtcrime.securesms.database;

public class NotInDirectoryException extends Throwable {
}
